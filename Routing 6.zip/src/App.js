
import './App.css';
import { Header } from './components/Header';
import { Routing} from './routing/Routing';

function App() {
  return (
   <div>
    <h1>Hello React</h1>
     <Routing/>
     <Header/>
   </div>
  );
}

export default App;
