import {Routes,Route} from "react-router-dom";
import {Home } from "../components/Home";
import {Dashboard} from "../components/Dashboard";
import {Table} from "../components/Table";


export const Routing = ()=>{

    return(

        <Routes>
         <Route path="/" element={<Home />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="table" element={<Table />} />
        </Routes>
   
    );
}

