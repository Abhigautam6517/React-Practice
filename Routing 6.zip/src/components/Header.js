import {Link} from 'react-router-dom'
export const Header = ()=>{
    return(
        <div>
             <ul>
                <li>
                <Link to='./home'>Home</Link>
                </li>
                <li>
                <Link to='./table'>table</Link>
                </li>
                <li>
                <Link to='./dashboard'>dashboard</Link>
                </li>
            </ul>
        </div>
    )
}