
export const Dashboard = ()=>{
    return(
        <div>
            <h2>I am Dashboard</h2>
            <h2>I am Dashboard page using Link rendering</h2>

        </div>
    )
}
