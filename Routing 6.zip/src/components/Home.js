import {Link} from 'react-router-dom'
export const Home=()=>{
    return(
        <div>
            <h1> Hello I am Home</h1>
           
            <h2>I am About page using Link rendering</h2>

        </div>
    )
}
