import React from "react";
import { useState } from "react";

const MovieRecomd=(props)=>{

    const[name,setname] =useState("");

    const ChangeHandler=(e)=>{
    const myValue = e.target.value
    setname(myValue)

    }

    const handleSubmit=(e)=>{
        e.preventDefault();
        props.onSubmit(name)
    }
   

  


   
    return(
        <form onSubmit = {handleSubmit}>
       <input type="text" value={name} onChange={ChangeHandler}></input>
        <button type="submit">submit</button>
        </form>
    )

}
export default MovieRecomd;