
import './App.css';
import React from 'react';
import { useState } from 'react';
import MovieRecomd from './components/MovieRecomd';

function App() {

const[Movie,setMovie] = useState('');

const clickHandler = (data)=>{
  console.log("My data is",data)
  Movie(data)
}


  return (
    <div className="App">
      <MovieRecomd onSubmit = {clickHandler}/>
      {Movie?<h1>I am Netflix</h1>:<h1>I am Amazon</h1>}
    </div>
  );
}

export default App;
