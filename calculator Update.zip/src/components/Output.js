export const Output = ({count})=>{
    return(
        <div>
            <input value={count} type="text" placeholder="Calculate"/>
        </div>
    )
}