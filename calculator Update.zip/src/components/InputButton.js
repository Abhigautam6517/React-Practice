export const InputButton=({btn,fn})=>{
    const btnClick=(event)=>{
        var value = event.target.innerText;
        fn(value);

    }
    return(
        <div>
            <button onClick={btnClick}>{btn}</button>
        </div>
    )
}