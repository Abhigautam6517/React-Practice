export const Operation = ({fn})=>{
    const clickbtn=()=>{
        fn();
    }
    return(
        <div className = "operation">
            <button onClick={clickbtn}>=</button>
        </div>
    )
} 