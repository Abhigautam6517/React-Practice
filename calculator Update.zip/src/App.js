
import {Calc} from './container/Calc.js';
function App() {
  return (
    <div className="main">
      <Calc/>
    </div>
  );
}

export default App;
