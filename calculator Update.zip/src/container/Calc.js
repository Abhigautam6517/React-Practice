import { useState } from 'react';
import { InputButton } from '../components/InputButton';
import { Operation } from '../components/Operation';
import { Output } from '../components/Output';
import './calc.css';
export const Calc = ()=>{
    // var expression = 0;
    const [count,setCount]=useState("");
    const takeValue=(value)=>{
        // expression +=value;
        setCount(count+value);
        console.log("hello",count)

    }
    const solveExpression=()=>{
        // console.log("hii am Expression")
        setCount(eval(count));
    }
    return(
        <div className = 'container'>
            <h2>Calculator App</h2>
            <Output count = {count}/>
            <table>
                <tbody>
                    <tr>
                        <td><InputButton fn={takeValue}btn="8"/></td>
                        <td><InputButton  fn={takeValue} btn="7"/></td>
                        <td><InputButton fn={takeValue} btn="9"/></td>
                        <td><InputButton fn={takeValue} btn="/"/></td>
                    </tr>
                    <tr>
                        <td><InputButton fn={takeValue} btn="4"/></td>
                        <td><InputButton fn={takeValue} btn="5"/></td>
                        <td><InputButton fn={takeValue} btn="6"/></td>
                        <td><InputButton fn={takeValue} btn="*"/></td>
                    </tr>
                    <tr>
                        <td><InputButton fn={takeValue} btn="1"/></td>
                        <td><InputButton fn={takeValue} btn="2"/></td>
                        <td><InputButton fn={takeValue} btn="3"/></td>
                        <td><InputButton fn={takeValue} btn="-"/></td>
                    </tr>
                    <tr>
                        <td><InputButton fn={takeValue} btn="0"/></td>
                        <td><InputButton fn={takeValue} btn="."/></td>
                        <td><InputButton fn={takeValue} btn="+"/></td>
                       
                    </tr>
                </tbody>
            </table>
            <Operation fn={solveExpression}/>
           
        </div>
    )
}