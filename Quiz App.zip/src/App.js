import { useState } from "react";
import "./App.css";
import 'bootstrap/dist/css/bootstrap.min.css';

const questions = [
  {
    questionText: "What of the following is used in React.js to increase performance?",
    answerOptions: [
      { answerText: "Original DOM", isCorrect: false },
      { answerText: "Virtual DOM", isCorrect: true },
      { answerText: "Both A and B.", isCorrect: false },
      { answerText: "None of the above.", isCorrect: false },
    ],
  },
  {
    questionText:
      " Which of the following acts as the input of a class-based component?",
    answerOptions: [
      { answerText: "Class", isCorrect: false },
      { answerText: "Factory", isCorrect: false },
      { answerText: "Rener", isCorrect: false },
      { answerText: "Props", isCorrect: true },
    ],
  },
  {
    questionText: "Which Company Build IPhone",
    answerOptions: [
      { answerText: "Apple", isCorrect: true },
      { answerText: "Intel", isCorrect: false },
      { answerText: "Amazon", isCorrect: false },
      { answerText: "Microsoft", isCorrect: false },
    ],
  },
  {
    questionText: "What is the default port where webpack-server runs?",
    answerOptions: [
      { answerText: "3000", isCorrect: false },
      { answerText: "3080", isCorrect: true },
      { answerText: "3030", isCorrect: false },
      { answerText: "6060", isCorrect: false },
    ],
  },
];


function App() {

  const [showScore, setShowScore] = useState(false);
  const [score, setScore] = useState(0);
  const [currentQuestion, setCurrentQuestion] = useState(0);

  function handleAnswer(isCorrect) {
    if (isCorrect) {
      setScore(score + 1);
    }

    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion);
    } else {
      setShowScore(true);
    }
  }

  return (

   
    
    <div className="app">
      
      
      {showScore ? (
        <div className="score-section">
          Your Correct Answer {score} is {questions.length}
        </div>
      ) : (
        <>
          <div className="question-section">
            <div className="question-count">
              <span>Question {currentQuestion + 1}</span>/{questions.length}
            </div>
            <div className="question-text">
              {questions[currentQuestion].questionText}
            </div>
          </div>

          <div className="answer-section">
            {questions[currentQuestion].answerOptions.map(
              (answerOption, index) => (
                <button
                  onClick={() => handleAnswer(answerOption.isCorrect)}
                  key={index}
                >
                  {answerOption.answerText}
                </button>
              )
            )}
          </div>
        </>
      )}
      
    </div>
    
  );
}

export default App;
