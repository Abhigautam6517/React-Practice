
import { numberActionCreator } from '../redux/action/Action';
import { store } from '../redux/store';
import './Button.css';
const Button =({label})=>{
    const opr = ()=>{
        const type = label==='Add'?"ADD":"DLT";
        const action = numberActionCreator(type,"");
        store.dispatch(action);
    }
    return(
        <div className='btn-container'>
           <button  onClick={opr} className="btn btn-primary">{label}</button>
        </div>
    )
}
export default Button;