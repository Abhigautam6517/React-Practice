import { useSelector } from "react-redux";
const Table = ()=>{
  const item_code = useSelector(state=>state.item);
  const amt = useSelector(state=>state.amt);
  // const rate = useSelector(state=>state.rate);
  const item_name = useSelector(state=>state.item_name);
  const unit = useSelector(state=>state.unit);
  const qty = useSelector(state=>state.qty);
    return(
        <table className="table">
  <thead>
    <tr>
      <th scope="col">Item_code</th>
      <th scope="col">Item_Name</th>
      <th scope="col">Quantity</th>
      <th scope="col">unit</th>
      <th scope="col">Amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">{item_code}</th>
      <td>{item_name}</td>
      <td>{qty}</td>
      <td>{unit}</td>
      <td>{amt}</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
      <td>fddt</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Larry the Bird</td>
      <td>Instagram</td>
      <td>@twitter</td>
      <td>twitter</td>
    </tr>
  </tbody>
</table>
    )
}
export default Table;