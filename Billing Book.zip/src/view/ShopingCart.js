import {useSelector} from "react-redux";
const ShopingCart = ()=>{
    const amt = useSelector(state=>state.result);
    
    return(
        <div>
        <br></br>
          <p>Subtotal: {amt} </p>
          <p>Total Tax: 18%</p>
          <p>Total Amount: {amt} </p>
          <p>Discount:6% </p>
          <p>Recived Amount:  </p>
      </div>
       
    )
}
export default ShopingCart;