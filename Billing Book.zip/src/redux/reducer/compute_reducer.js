export const computeReducer=(state={result:1,item:0,item_name:"",qty:0,unit:"",rate:0,amt:0},action)=>{
    if(action.type==='ADD'){
        let temp = state.amt;
        temp = temp +action.payload;
        return {...state, result:temp}
    }
    else if(action.type==='DLT'){
        let temp = state.result;
        temp = 0;
        return {...state, result:temp}

    }
    else if(action.type==='handleInput'){
        let temp = state.item;
        temp = action.payload;
        return {...state, item:temp}
    }
    else if(action.type==='itemName'){
        let temp = state.item_name;
        temp = action.payload;
        return {...state, item_name:temp}
    }
    else if(action.type==='qtyInput'){
        let temp = state.qty;
        temp = action.payload;
        return {...state, qty:temp}
    }
    else if(action.type==='unitInput'){
        let temp = state.unit;
        temp = action.payload;
        return {...state, unit:temp}
    }
    else if(action.type==='rateInput'){
        let temp = state.rate;
        temp = action.payload;
        return {...state, rate:temp}
    }
    else if(action.type==='amtHandler'){
        let temp = state.amt;
        temp = action.payload;
        return {...state, amt:temp}
    }
    return state;
}