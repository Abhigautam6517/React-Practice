export const numberActionCreator=(type,data)=>{
    return{
        type:type,
        payload:data
        
    }
}