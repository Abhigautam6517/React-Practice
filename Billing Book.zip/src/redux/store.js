import {createStore} from "redux";
import { computeReducer } from "./reducer/compute_reducer";

export const store = createStore(computeReducer);
store.subscribe(state=>{
    console.log('State Update....',state)
})