import Table from "../UI/Table";
import ShopingCart from "../view/ShopingCart";
import Button from "../widgets/Button";
import "./Dashboard.css";
import { store } from '../redux/store';
import { numberActionCreator } from '../redux/action/Action';
const Dashboard = () => {

  const handleInput = (event)=>{
    const type = 'handleInput';
    const action = numberActionCreator(type,event.target.value);
    store.dispatch(action);
}
const itemName = (event)=>{
  const type = 'itemName';
  const action = numberActionCreator(type,event.target.value);
  store.dispatch(action);
}
const qtyInput = (event)=>{
  const type = 'qtyInput';
  const action = numberActionCreator(type,event.target.value);
  store.dispatch(action);
}
const unitInput = (event)=>{
  const type = 'unitInput';
  const action = numberActionCreator(type,event.target.value);
  store.dispatch(action);
}
const rateInput = (event)=>{
  const type = 'rateInput';
  const action = numberActionCreator(type,event.target.value);
  store.dispatch(action);
}
const amtHandler = (event)=>{
  const type = 'amtHandler';
  const action = numberActionCreator(type,event.target.value);
  store.dispatch(action);
}
  return (
    <div className="main-box">
      <div className="container text-center">
        <div className="row">
          <div className="col">
            <h1 className="text-info bg-dark ">Abhishek Cart Store</h1>
          </div>
          <div className="col">
          <label>Date:</label>
            <input type="date" id="date" name="date"/>
          </div>
          <div className="col">
          <label>Bill Time:</label>
            <input type="text" value="11:13:2022" readOnly={true} />
          </div>
        </div>
    
        <hr></hr>
        <br></br>
  
        <div className="row">
          <div className="col">
          <label>Bill No:</label>
            <input type="text" value="06" readOnly={true} />
         
          </div>
          <div className="col">
          <label >Customer : </label>
            <select>
                <option value="money">Cash</option>
                <option value="money">Debit Card</option>
                <option value="money">Net Banking</option>
                <option value="money">Credit Card</option>
            </select>
          </div>
          <div className="col">
          <label>Mobile No. :</label>
            <input type="number"/>
          </div>
        </div>
  <br></br>
 
  <hr></hr>
    <div className="row">
    <div className="col">
     <label>Item_code</label>
     <input onChange={handleInput} type="text"></input>
    </div>
    <div className="col">
    <label>Item_Name</label>
     <input onChange={itemName} type="text"></input>
    </div>
    <div className="col qty">
    <label >Qty</label>
     <input onChange={qtyInput}  type="number"></input>
    </div>
    
    <div className="col unit">
        <label>Unit</label>
    <select onChange={unitInput}>
        <option value="ltr">ltr</option>
        <option value="KG">KG</option>
        <option value="g">g</option>
    </select>
    </div>
    <div className="col rate">
    <label>Rate</label>
     <input onChange={rateInput} type="number"></input>
    </div>
    <div className="col amt">
    <label>Amt</label>
     <input onChange={amtHandler} type="number"></input>
    </div>
    
  </div>
  <br></br>
   <hr></hr>

   <div className="row">
    <div className="col">
     <Button label ="Add"/>
    </div>
    <div className="col">
    <Button label ="Edit"/>
    </div>
    <div className="col">
    <Button label ="Delete"/>
    </div>
  </div>
  <br></br>
  <hr></hr>

 
  <div className="row">
   <Table/>
  </div>


        
        
      </div>


    

      <div className= "col2 cart">
        <h2>Shoping Cart</h2>
        <ShopingCart/>

      </div>
    </div>
  );
};
export default Dashboard;
