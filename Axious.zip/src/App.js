
import './App.css';

import Axois from './components/Axois.js';

function App() {
  return (
    <div className="App">
      <h1>I am App</h1>
      <Axois/>
    </div>
  );
}

export default App;
