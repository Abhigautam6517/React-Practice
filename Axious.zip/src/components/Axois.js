import React, { useEffect, useState } from "react";
import axios from 'axios';





const Axois = () => {

    const[num,setNum]=useState('');
    const[name,setName]=useState('');
    const[move,setMoves]=useState('');
    

    useEffect(()=>{
        async function getData(){
            const res = await axios.get(`https://pokeapi.co/api/v2/pokemon/${num}`);
            console.log(res);
            setName(res.data.name);
            setMoves(res.data.moves.length);

        }
        getData();
    })
    


    const valueHandler = (event) => {
        console.log(event.target.value);
        setNum(event.target.value)
      };
      
  return (
    <div>
      <h1>You choose {num} value</h1>
      <h1>My Name is {name}</h1>
      <h1>I have {move} moves</h1>
      <select  value={num} onChange={valueHandler}>
        <option value="1">1</option>
        <option value="25">25</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
      </select>
    </div>
  );
};

export default Axois;
