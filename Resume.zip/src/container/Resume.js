
import {Proffile} from '../components/Proffile.js';
import {Menu} from '../components/Menu.js';
import './Resume.css'
import { About } from '../components/about/About.js';
import { Service } from '../components/service/Service.js';

export const Resume=()=> {
    return (
      <div className = "container">
        <div className = 'menu'>
            <Menu/>
        </div>
        <div className="profile">
        <Proffile/>
        </div>

        <div className = 'heading'>
        <About/>
        <Service />
      
        
        
        </div>
       
      </div>
     
      
    );
  }

  