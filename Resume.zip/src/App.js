
import './App.css';
import {Resume} from './container/Resume';


function App() {
  return (
    <div>
      <Resume/>
    </div>
   
    
  );
}

export default App;
