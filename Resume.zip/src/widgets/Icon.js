// import { Menu } from "../components/Menu"

// const export Icon = ()=>{
//     return(
//         <div>
//             <Menu logo = ""/>
//         </div>
//     )
// }