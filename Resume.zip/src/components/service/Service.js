
import './Service.css';
import {IoIosFitness} from "react-icons/io";
import {IoIosBug} from "react-icons/io";
import {IoLogoVimeo} from "react-icons/io";
import {IoLogoPython} from "react-icons/io";

export const Service = ()=>{
    return(
        <div className="service">
            <h2>My service</h2>
            <div className="developemnt">
            <h3><IoIosFitness/></h3>
            <h4>Development</h4>
            <p>The process of test  includes different steps and different phases.. </p>
            </div>
       
            <div className="seo">
            <h3><IoIosBug/></h3>
            <h4>SEO Optimization</h4>
            <p>SEO means Search Engine Optimization and is the process used to optimize.</p>
            <p></p>
            </div>
            <div className="base">
            <h3><IoLogoVimeo/></h3>
            <h4>DataBase</h4>
           <p>A database is an organized collection of  or data, typically stored.. </p>
            </div>
            <div className="security">
            <h3><IoLogoPython/></h3>
            <h4>Data-Security</h4>
            <p>Data security is the practice of protecting digital information.</p>
            </div>

            
        </div>
    )

}