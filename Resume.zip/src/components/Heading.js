

export const Heading=()=>{
    return(
        <div>
        <h1>Hello</h1>
        </div>
    )
}