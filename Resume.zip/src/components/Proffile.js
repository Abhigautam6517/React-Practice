import './Profile.css';
import MyImage from './Img.jpg';
import {IoIosPaperPlane} from "react-icons/io";
import {IoLogoTwitter} from "react-icons/io";
import {IoLogoWhatsapp} from "react-icons/io";
import {IoLogoLinkedin} from "react-icons/io";


export const Proffile=()=> {
  return (
    <div className = "Img-src">

      <img src={MyImage} alt="horse" />
      <h1 className = "name">Jiko Names</h1>
      <p>Developer</p>
      <h2><IoIosPaperPlane/></h2>
      <h2><IoLogoTwitter/></h2>
      <h2><IoLogoWhatsapp/></h2>
      <h2><IoLogoLinkedin/></h2>

    </div>
  );
}