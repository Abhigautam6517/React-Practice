export const About = ()=>{
   return(
    <div>
    <h1>about me</h1>
    <p>
    A full stack developer works with both the client and server sides of a software application. They possess a wide range of coding skills, and can adapt to help other programmers solve problems, <br></br>regardless if they work on the back end (client) or front end (server) sides of a project.
    </p>
    <br/>
    <br/>
    <br/>
    </div>
   );

}