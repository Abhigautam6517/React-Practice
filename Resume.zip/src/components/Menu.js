import './Profile.css';

import { IoLogoBuffer } from "react-icons/io";
import { IoIosBusiness } from "react-icons/io";
import {IoIosCall} from "react-icons/io";
import {IoIosHome} from "react-icons/io";
import {IoLogoGithub} from "react-icons/io";
import {IoLogoGoogleplus} from "react-icons/io";
import {IoMdCloudDownload} from "react-icons/io";




export const Menu = ()=>{
    return(
        <div className='main-p'>
        <p className = "main"><IoLogoBuffer/></p>
        <div className = 'nav'>
            <p><IoIosHome/> </p>
            <p><IoIosCall/></p>
            <p><IoLogoGithub/></p>
            <p><IoLogoGoogleplus/></p>
            <p><IoIosBusiness/></p>
        </div>
        <p className = "main"><IoMdCloudDownload/></p>
    </div>
    )
}