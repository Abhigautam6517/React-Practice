import { useState } from "react";
import { Operation } from "../components/Operation";
import { Output } from "../components/Output";
import './counter.css';

export const Counter=()=>{
    // var counter = 0;
    const[count,setCount]=useState(0);
    const plus = ()=>{
        // counter = counter+1;
        setCount(count+1);
        console.log(" I am plus",count);
    }
    const minus= ()=>{
        //  counter = counter-1;
        setCount(count-1); 
        console.log(" I am minus",count)
    }

    return(
        <div className = "container">
        <h1 className="heading">Counter-App</h1>
        <Output count = {count}/>
        <Operation title = "+" operation={plus}/>
        <Operation title = "-" operation={minus}/>
        </div>
    )
}