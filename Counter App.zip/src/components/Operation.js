import '../container/counter.css';
export const Operation =(props)=>{
    const btnclick=()=>{
        props.operation();

    }
    return(
        <div className='button'>
            <button onClick={btnclick}>{props.title}</button>
        </div>
    )

}