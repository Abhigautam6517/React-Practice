export const Output = (props)=>{
    return(
        <div className="output">
          <h3>Counter is {props.count}</h3>  
        </div>

    );
}