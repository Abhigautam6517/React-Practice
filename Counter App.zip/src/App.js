import {Counter} from './container/Counter'
import './App.css';

function App() {
  return (
   <Counter/>
  );
}

export default App;
