export const Error = ()=>{
    return (<h1>U Type Something Wrong....</h1>);
}