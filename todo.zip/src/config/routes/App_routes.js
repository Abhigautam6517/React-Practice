import { Navigate, useRoutes } from "react-router-dom"
import { AddTask } from "../../modules/tasks/crud/presentation/pages/Add"
import { Summary } from "../../modules/tasks/crud/presentation/pages/Summary"
import { View } from "../../modules/tasks/crud/presentation/pages/View";

export const AppRoutes = ()=>{
    const allRoutes = useRoutes([
        {path:'/',element:<Summary/>},{path:'/add', element:<AddTask/>},
        {path:'/view',element: ()=> <Navigate to={"/views"} replace={<View/>} />}
    ]);
    return allRoutes;
}