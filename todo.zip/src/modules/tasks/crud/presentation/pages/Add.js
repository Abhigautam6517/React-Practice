import { useContext, useRef, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import TaskModel from "../../domain/models/task_model";
import { task_context } from "../../provider/task_context";
export const AddTask = (props)=>{
    const [errors, setErrors] = useState({});
    const id = useRef('');
    const name = useRef('');
    const color = useRef('');
    const date = useRef('');
    const navigate = useNavigate(); 
   // const history = useHistroy();   // Old Version
    const context = useContext(task_context)
    const doValidate = ()=>{
        const e = {isValid:true};
        if(id.current.value.length==0){
            e.errorid = 'Id is Blank';
            e.isValid = false;
            
        }
        else {
            e.errorid = '';
        }
         if (name.current.value.length ==0){
            e.errorname='Name is Blank';
            e.isValid = false;
        }
        else{
            e.errorname = '';
        }
        if(e.isValid){
            let idData = id.current.value;
            let nameData = name.current.value;
            let colorData = color.current.value;
            let dateData = date.current.value;
            let task = new TaskModel(idData, nameData, colorData, dateData, "I"); 

            context.tasks.push(task);
            console.log('Data Store in Context ', context.tasks);
            // Navigate
            //console.log(typeof navigate);
            //history.push('/view/U');
            navigate("/view/U",{
                 state:{"x":10 , "y":20}
             });

        }
        else{
        setErrors(e);
        }
    }
    //console.log('Props is ', props);
    const [param, setParam] = useSearchParams(); // QueryString Param
    console.log('Type Param ', param);
    //const qs = props.location.search;
    //const u = new URLSearchParams(type);
    let flag = "";
    param.forEach(w=>console.log('********Value is ',w));
    param.forEach(w=>{
        if(flag ==""){
            flag = w;
        }
    });
    return (
    <div>
    <h1 className='alert-info'> {flag=='a'?"Add":"Update"} task</h1>
    <div className = 'form-group'>
        <label>Id </label>
        <input ref={id} type='text' className="form-control"  />
        <span>{errors.errorid}</span>
    </div>
    <div className = 'form-group'>
        <label>Name </label>
        <input ref={name} type='text' className="form-control"  />
        <span>{errors.errorname}</span>
    </div>
    <div className = 'form-group'>
        <label>Color </label>
        <input ref={color} type='color' className="form-control"  />
    </div>
    <div className = 'form-group'>
        <label>Date </label>
        <input ref={date} type='date' className="form-control"  />
    </div>
    <div className = 'form-group'>
        <label>Importance </label>
        <select className="form-control"  >
            <option>Moderate</option>
            <option>Critical</option>
            </select>
    </div>
    <br/>
    <div className='form-group'>
        <button onClick={doValidate} className='btn btn-primary'>Add a Task</button>
        &nbsp;
        <button className='btn btn-secondary'>Clear All</button>
    </div>
    </div>);
}