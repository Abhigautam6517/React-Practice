import React from 'react';
import { useState } from 'react';
const Form=(props)=>{

    const[value,setValue] = useState("");
    const[value1,setValue1] = useState("");
    const[value2,setValue2] = useState("");

    const clickHandler=(e)=>{
        const value = e.target.value
        setValue(value)
        console.log(value)

    }

    const clickHandler2=(e)=>{
        const value2 = e.target.value
        setValue1(value2)
        console.log(value2)

    }

    const clickHandler3=(e)=>{
        const value3 = e.target.value
        setValue2(value3)
        console.log(value3)

    }

    const submitData=(e)=>{
        e.preventDefault();
        props.onSubmit({value,value1,value2})

    }
    return(
        <form onSubmit = {submitData}>
            <label>Enter your name</label>
            &nbsp; &nbsp; &nbsp; &nbsp;
            <input type="text" value={value} onChange={clickHandler}></input>
            <label>Enter your Father name</label>
            &nbsp; &nbsp; &nbsp; &nbsp;
            <input type="text" value={value1} onChange={clickHandler2}></input>
            <label>Enter your Age</label>
            &nbsp; &nbsp; &nbsp; &nbsp;
            <input type="number" value={value2} onChange={clickHandler3}></input>

            <button type='submit'>submit</button>
        </form>
    )
}
export default Form;