import React from "react";
const PrintForm=(props)=>{
    return(
        <div>
            <h1>{props.value}</h1>
            {/* <h2>{props.father}</h2>
            <h3>{props.age}</h3> */}
        </div>
    )
}
export default PrintForm;