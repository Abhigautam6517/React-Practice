import React from "react";


const PrintForm=(props)=>{
    return(
        <div>
            <h1>{props.transfer.value1}</h1>
            <h2>{props.transfer.value2}</h2>
            <h3>{props.transfer.value3}</h3>
        </div>
    )
}
export default PrintForm;