import React from 'react';
import { useState } from 'react';
const Form=(props)=>{

    const[value1,setValue1] = useState("");
    const[value2,setValue2] = useState("");
    const[value3,setValue3] = useState("");

    // const clickHandler=(e)=>{
    //     const value = e.target.value
    //     setValue1(value)
    //     console.log(value)

    // }

    const clickHandler = (e)=>{
        switch(e.target.id)
        {
           
            case "name":
                setValue1(e.target.value);
                break;
            case "father":
                setValue2(e.target.value);
                break;
            case "age":
                setValue3(e.target.value);
                break;
            
             
        }
                

    }

    // const clickHandler2=(e)=>{
    //     const value2 = e.target.value
    //     setValue1(value2)
    //     console.log(value2)

    // }

    // const clickHandler3=(e)=>{
    //     const value3 = e.target.value
    //     setValue2(value3)
    //     console.log(value3)

    // }

    const submitData=(e)=>{
        e.preventDefault();
        setValue1("")
        setValue2("")
        setValue3("")
        props.onSubmit({value1,value2,value3})

    }
    return(
        <form onSubmit = {submitData}>
            <label>Enter your name</label>
            &nbsp; &nbsp; &nbsp; &nbsp;
            <input id="name" type="text" value={value1} onChange={clickHandler}></input>
            <label>Enter your Father name</label>
            &nbsp; &nbsp; &nbsp; &nbsp;
            <input id="father" type="text" value={value2} onChange={clickHandler}></input>
            <label>Enter your Age</label>
            &nbsp; &nbsp; &nbsp; &nbsp;
            <input id="age" type="number" value={value3} onChange={clickHandler}></input>

            <button type='submit'>submit</button>
        </form>
    )
}
export default Form;