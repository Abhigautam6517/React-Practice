import React from 'react';
import { useState } from 'react';
import './App.css';
import Form from './components/Form';
import PrintForm from './components/PrintForm';

function App() {

  const[newValue1,setnewValue1] = useState("")
  // const[newValue2,setnewValue2] = useState('')
  // const[newValue3,setnewValue3] = useState('')

  // const getData=(data)=>{
  //   setnewValue1(data.value)
  //   setnewValue2(data.value1)
  //   setnewValue3(data.value2)
  //   console.log(data.value)
  //   console.log(data.value1)
  //   console.log(data.value2)
  // }
  return (
    <div className="App">
      <h2>Child to parent Communication</h2>
      <h3>Child to parent Communication</h3>
      <Form onSubmit = {setnewValue1}/>
      <PrintForm transfer = {newValue1} />
    </div>
  );
}

export default App;
