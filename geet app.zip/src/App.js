
import './App.css';
import {Greet} from './container/Greet.js';

function App() {
  return (
   <Greet/>
  );
}

export default App;
