export const Operations = ({label, color, fn})=>{
    const myClass = `btn ${color} me-2`;
    return (<button onClick={fn} className={myClass}>{label}</button>)
}