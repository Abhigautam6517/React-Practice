export const Message = ({msg})=>{
    return (<h3 className='alert-info text-center'>{msg}</h3>)
}