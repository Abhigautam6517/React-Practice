export const Input = ({val, lbl, takeinput})=>{
    const placeHolder = `Type ${lbl}`;
    const key = lbl.split(" ")[0].toLowerCase();
    return (<div className='form-group'>
        <label>{lbl}</label>
        <input value = {val}  onChange = {(event)=>{
            takeinput(event, key);
        }} type='text' className='form-control' placeholder = {placeHolder} />
    </div>)
} 