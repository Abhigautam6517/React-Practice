import React ,{Component} from 'react';
import { Input } from '../components/Input';
import { Message } from '../components/Message';
import { Operations } from '../components/Operations';
export class Greet extends React.Component{
    constructor(){
 
        super(); 
        this.names ={first:'', last:''};
        this.msg = '';
        this.state = {msg : this.msg};
    }
    takeInput(event, key){
        let value = event.target.value;
        this.names [key] = value;

        console.log('take Input Call ', this.names);
        this.setState({msg : this.msg});
    }
    greet(){
        this.msg = 'Welcome '+this.initCap(this.names.first)+" "+this.initCap(this.names.last);
        console.log('Message is ',this.msg);
        this.setState({msg: this.msg});
    }
    clearAll(){
        this.msg = '';
        this.names = {first:'', last:''};
        this.setState({msg: this.msg});
    }
    initCap(name){
            return name.charAt(0).toUpperCase()+name.substring(1).toLowerCase();
    }

    render(){
        return (<div className = 'container'>
                <Message msg='Greet App'/>
                <Input val = {this.names.first} takeinput = {this.takeInput.bind(this)} lbl="First Name"/>
                <Input val = {this.names.last} takeinput = {this.takeInput.bind(this)} lbl="Last Name"/>
                <br/>
                <Operations fn = {()=>{
                    this.greet();
                }} label='Greet' color = 'btn-primary'/>
                <Operations fn = {()=>{
                    this.clearAll();
                }} label='Clear All' color = 'btn-danger'/>
                <Message msg={this.state.msg}/>
        </div>)
    }
}