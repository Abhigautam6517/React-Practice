
import Building from "./Building"
import Navbar from "./Navbar/Navbar";

import '../App.css';


const MainCompoent=(props)=>{
    return(
    <div clssName="main">
    <Navbar name="Google" link="https://www.google.com/search?q=google"/>
    <Navbar name="Linkedn" link="https://www.google.com/search?q=google"/>
    <Navbar name="Github" link="https://www.google.com/search?q=google"/>
    <Navbar name="Instagram" link="https://www.google.com/search?q=google"/>
    

     <Building name = "building" para = "A container is any receptacle or enclosure for holding a product used in storage, packaging, and transportation, including shipping. Things kept inside of a container are protected on several sides by being inside of its structure."/>


     <Building name = "About" para = "A storage, packaging, and transportation, including shipping. Things kept inside of a container are protected on several sides by being inside of its structure."/>


     <Building name = "Planing" para = "A  product used in storage, packaging, and transportation, including shipping. Things kept inside of a container are protected on several sides by being inside of its structure."/>

     
    </div>
    )
}
export default MainCompoent;