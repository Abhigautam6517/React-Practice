const Navbar=(props)=>{
    return(
        <ul>
            <li>
                <a href={props.link}>{props.name}</a>
            </li>
        </ul>
    )
}
export default Navbar;