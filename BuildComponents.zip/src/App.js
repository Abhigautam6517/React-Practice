
import './App.css';
import MainCompoent from './Components/MainComponent';


function App() {
  return (
    <div className="App">
    <MainCompoent/>
    </div>
  );
}

export default App;
