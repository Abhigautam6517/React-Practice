import React from 'react'
import AddUser from '../components/AddUser'
import UserList from '../components/UserList'

const CrudUser = () => {
  return (
    <div className='container'>
        <AddUser/>
        <UserList/>
    </div>
  )
}

export default CrudUser