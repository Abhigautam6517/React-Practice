import { createSlice } from "@reduxjs/toolkit";

const UserSlice = createSlice({
    name:'users',
    initialState:[],
    reducers:{
        addUser(state,action){
            state.push(action.payload);

        },
        EditUser(state,action){
            
        },
        DeleteUser(state,action){
            
        },
        ViewUser(state,action){
            
        }
    }
});
export const {addUser,DeleteUser,ViewUser,EditUser} = UserSlice.actions;
export const userReducers  = UserSlice.reducer;