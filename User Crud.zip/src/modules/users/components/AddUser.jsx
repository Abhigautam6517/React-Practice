import React, { useRef } from 'react'
import { useDispatch } from 'react-redux';
import { addUser } from '../redux/UserSlice';

const AddUser = () => {
    const name = useRef('');
    const email = useRef('');
    const password = useRef('');
    const phone = useRef('');
    const dispatch = useDispatch();

    const addbtn=()=>{
       const userObject = {
        'name':name.current.value,
        'email':email.current.value,
        'password':password.current.value,
        'phone':phone.current.value

    }
   dispatch(addUser(userObject));

    }
  return (
    <>
    <h1>User Crud Operation</h1>
    <div className='form-group'>
        <label>Name</label>
        <input ref={name} type="text" className='form-control' placeholder='Type Your Name Here'></input>

        <label>Email Id</label>
        <input ref={email} type="text" className='form-control' placeholder='Type Your Email Id'></input>

        <label>Password</label>
        <input ref={password} type="password" className='form-control' placeholder='Type Your Password'></input>
        <label>Phone</label>
        <input ref={phone} type="number" className='form-control' placeholder='Type Your Mobile Number'></input>
    </div>
    <br></br>
    <button onClick={addbtn} className='btn btn-primary'>Add</button>
    </>
  )
}

export default AddUser;