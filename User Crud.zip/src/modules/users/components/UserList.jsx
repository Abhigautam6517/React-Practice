import React from 'react'
import { useSelector } from 'react-redux'

const UserList = () => {
    const allUser = useSelector((state)=>state.users)
  return (
    <div>
           <table className="table table-striped table-hover">
        <thead>
    <tr className='table-dark'>
    <th scope="col">S.No</th>
    <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Password</th>
      <th scope="col">Phone</th>
     
    </tr>
  </thead>
  <tbody>
    {allUser.map((user,index)=>{
        return(<tr  key={index}>
            <td>{index+1}</td>
            <td>{user.name}</td>
            <td>{user.email}</td>
            <td>{user.password}</td>
            <td>{user.phone}</td>
        </tr>)
    })}
   
  </tbody>
  </table>
    </div>
  )
}

export default UserList