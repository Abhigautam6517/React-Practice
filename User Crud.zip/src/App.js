
import './App.css';

import CrudUser from './modules/users/pages/CrudUser';

function App() {
  return (
    <div className="App">
     <CrudUser/>
    </div>
  );
}

export default App;
