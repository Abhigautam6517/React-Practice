import {configureStore} from '@reduxjs/toolkit';
import { userReducers } from '../../modules/users/redux/UserSlice';

export const store = configureStore({
    reducer:{'users':userReducers}
})