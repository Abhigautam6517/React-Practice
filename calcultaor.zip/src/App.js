
import { Component } from 'react';
import './App.css';
import {Button} from './components/Button.js';
import {Input} from './components/Input.js';
import {ClearButton} from './components/ClearButton.js';
import {
  atan2, chain, derivative, e, evaluate, log, pi, pow, round, sqrt
} from 'mathjs';

class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      input:""
    };
    
  }
  addToInput = (val)=>{
    this.setState({input:this.state.input + val});
  };

  handleEqual=()=>{
    this.setState({input: evaluate(this.state.input)});
  };
  
  render(){
    return(
      <div className="app">
        <div className="calc-wrapper">
          <Input input = {this.state.input}> </Input>
          <div className="row">
          <Button childern = "7" handleonclick = {this.addToInput}/>
          <Button childern = "8" handleonclick = {this.addToInput} />
          <Button childern = "9" handleonclick = {this.addToInput} />
          <Button childern = "/" handleonclick = {this.addToInput} />

          </div>
          <div className="row">
          <Button childern = "4" handleonclick = {this.addToInput} />
          <Button childern = "5" handleonclick = {this.addToInput} />
          <Button childern = "6" handleonclick = {this.addToInput} />
          <Button childern = "*" handleonclick = {this.addToInput} />

          </div>
          <div className="row">
          <Button childern = "1"  handleonclick = {this.addToInput}/>
          <Button childern = "2" handleonclick = {this.addToInput}/>
          <Button childern = "3" handleonclick = {this.addToInput} />
          <Button childern = "+" handleonclick = {this.addToInput} />

          </div>
          <div className="row">
          <Button childern = "." handleonclick = {this.addToInput}/>
          <Button childern = "0" handleonclick = {this.addToInput} />
          <Button childern = "=" handleonclick = {()=>this.handleEqual()}/>
          <Button childern = "-" handleonclick = {this.addToInput}/>

          </div>
          <div className='row'>
           <ClearButton handleClear = {()=>this.setState({ input:""})} childern= "Clear"></ClearButton> 
          </div>
        </div>
      </div>
    )
  }
}
export default App;
