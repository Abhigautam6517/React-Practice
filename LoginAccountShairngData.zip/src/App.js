
import './App.css';
import {React,useState} from 'react';
import LoginComponent from './components/LoginComponent';
import UserInfoComponent from './components/UserInfoComponent'

function App() {

  const[userInfo,updateUserInfo] = useState("")

  // const getData = (data)=>{
  //   console.log(data.username)
  //   console.log(data.password)
  // }

  return (
    <div className = "container">
      <h2>Child to parent Communication</h2>
      <h3>Child to parent Communication</h3>
      <LoginComponent onSubmit  = {updateUserInfo} />
      <UserInfoComponent transfer = {userInfo}/>



    </div>
  );
}

export default App;
