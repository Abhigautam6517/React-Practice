import {React,useState} from 'react';

import './LoginComponent.css'
const LoginComponent=(props)=>{

    const[username,updateusername] = useState("abhigautam.5678@gmail.com")
    const[password,updatepassword] = useState(" ")
    

    const onLoginClick=(e)=>{
        e.preventDefault();
        updatepassword("")
        updateusername("")
        props.onSubmit({username,password})

    }


    const onTextChange = (e)=>{
        switch(e.target.id)
        {
           
            case "username":
                updateusername(e.target.value);
                break;
            case "password":
                updatepassword(e.target.value);
                break;
            
             
        }
                

    }

    return(
       <form onSubmit = {onLoginClick}>
        <label>Username</label>
        <input id="username" type="email" value={username} onChange = {onTextChange} ></input>

        <label>Password</label>
        <input id="password" type="password" value = {password} onChange = {onTextChange} ></input>
        <button>Login</button>
       </form>
    )
}

export default LoginComponent;