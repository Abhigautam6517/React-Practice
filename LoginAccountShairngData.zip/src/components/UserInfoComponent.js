const UserInfoComponent = (props)=>{
    return(
        <div>
            <h1>{props.transfer.username}</h1>
            <p>{props.transfer.password}</p>
        </div>
    )
}

export default UserInfoComponent;