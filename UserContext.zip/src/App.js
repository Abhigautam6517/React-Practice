
import './App.css';
import React,{createContext} from 'react'
import CompA from './components/CompA';

const FirstName = createContext();
const LastName = createContext();
function App() {
  return (
    <FirstName.Provider value={"Abhishek"}>
      <LastName.Provider value={"Gautam"}>
      <CompA/>
      </LastName.Provider>
    </FirstName.Provider>
      
  
  );
}

export default App;
export {FirstName, LastName}
