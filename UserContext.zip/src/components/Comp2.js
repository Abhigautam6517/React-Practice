// import Comp3 from "./Comp3";
import React, {useContext} from 'react'
import { FirstName,LastName } from "../App";

const Comp2 = ()=>{
    const fname = useContext(FirstName);
    const lname = useContext(LastName);
    return(
        <h4>
            My name is {fname}  {lname}
        </h4>
    )
}
export default Comp2;