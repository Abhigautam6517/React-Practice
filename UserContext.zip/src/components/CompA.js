import Comp2 from "./Comp2";



;
const CompA = ()=>{
    return(
    <Comp2/>
    )
}
export default CompA;