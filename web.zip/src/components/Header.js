import Button from '@mui/material/Button';
import { useState } from 'react';
import '../App.css'
const Header = (props)=>{
    const[value, newValue]  = useState("");


    const navbarHandler = (event)=>{
        let search = event.target.value;
        console.log(search)
    }
    const dataHandler=(e)=>{
        e.preventDefault();
        props.onSubmit({value}) 
    }
    return(
        <form onChange={dataHandler} className = "App">
            <input  onChange = {navbarHandler} type="text"></input>
            <Button variant="contained">Click</Button>
      
        </form>
    )
}
export default Header;