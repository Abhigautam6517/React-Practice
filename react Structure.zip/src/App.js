
import './App.css';
import MainFile from './views/MainFile';
import Navbar from './navbar/Navbar';
import Routing from './Routing/Routing';

function App() {
  return (
    <div>
       <Navbar/>
      <Routing/>
      <MainFile/>
    </div>
  
  );
}

export default App;
