

import '../styles/Main.css';
const MainFile = () => {
  return (
    <div className="container">
      <div className="main-content">Main - Content</div>
      <div className="item-2">box 1</div>
      <div className="item-3">box 2</div>
      <div className="item-4">box3</div> 
      
    </div>
  );
};
export default MainFile;
