export const Contact = ()=>{
    return(
        <div>
            <h1>I am Contact Page</h1>
        </div>
    )
}
