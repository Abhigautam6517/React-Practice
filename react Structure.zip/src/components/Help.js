export const Help = ()=>{
    return(
        <div>
            <h1>I am Help page</h1>
        </div>
    )
}
