export const Price = ()=>{
    return(
        <div>
            <h1>I am Price Page</h1>
        </div>
    )
}
