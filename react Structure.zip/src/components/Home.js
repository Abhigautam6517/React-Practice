export const Home = ()=>{
    return(
        <div>
            <h1>I am Home</h1>
        </div>
    )
}
