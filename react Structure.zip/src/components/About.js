export const About = ()=>{
    return(
        <div>
            <h1>I am About</h1>
        </div>
    );
}
