import React from "react";
import { Routes, Route } from "react-router-dom";
import {Home }from '../components/Home';
import {About} from '../components/About'
import {Help} from '../components/Help'
import {Contact} from '../components/Contact';
import {Price} from '../components/Price';


const Routing = () => {
  return (
    <div>
      <Routes>
        <Route exact path="/" element={<Home/>}/>
        <Route exact path="/about" element={<About/>} />
        <Route exact path="/help" element={<Help/>} />
        <Route exact path="/price" element={<Price />} />
        <Route exact path="/contact" element={<Contact />} /> 
      </Routes>
    </div>
  );
};
export default Routing;
