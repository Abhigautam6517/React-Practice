
import './App.css';
import {Calculator} from './components/Calculator.js';

function App() {
  return (
    <Calculator/>
   
  );
}

export default App;
