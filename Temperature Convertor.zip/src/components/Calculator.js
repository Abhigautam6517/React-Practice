import React from 'react';
import './Calc.css';

export class Calculator extends React.Component{
    constructor(props){
        super(props)
        this.state = {state:'c',temp:0}
    }

    handleCelsius=(event)=>{
        this.setState({scale:'c',temp:event.target.value})
        console.log("the value is",event.target.value)
    }
    handleFaherenheit=(event)=>{
        this.setState({scale:'f',temp:event.target.value})
        console.log("the value is",event.target.value)
    }
    render(){
        const temp = this.state.temp;
        const scale = this.state.scale;
        const celcius = scale === 'f' ? (temp - 32)*5/9: temp;
        const faherneit = scale === 'c' ? (temp*9/5) + 32 : temp;
        return(
            <div className='container'>
                <h2>Temperator Converator</h2>
                <p>Made By Abhishek Gautam</p>
                <fieldset className='fieldset1'>
                <label className = "label2">Celcius</label>
                
                <input value={celcius} onChange = {this.handleCelsius}/>
                
                
                 
                <input value={faherneit} onChange = {this.handleFaherenheit}/>
            
                 <label className = "label2">Faherneit</label>
                </fieldset>
            </div>
        )
    }

}