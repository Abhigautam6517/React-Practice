
import './App.css';

import Navbar from './component/navbar/Navbar.js';
import Introduction from './component/intro/Intro.js';


function App() {
  return(
  <>
    <Navbar/>
    <Introduction/>
   
   
  </>
  );
}

export default App;
