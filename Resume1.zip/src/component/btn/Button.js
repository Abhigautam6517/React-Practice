import './Button.css';

function Buttons(props){
   return(
   <button>{props.btn}</button>
 
 );
}
export default Buttons;