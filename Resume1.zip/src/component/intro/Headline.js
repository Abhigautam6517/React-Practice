

function Headline(props){
    return(
        <div classname= "headline">
        <p>Goal oriented, focused computer science graduate<br></br> with an eye for detail. Complete knowledge of programming languages like <br></br> <b>MERN STACK</b> and <b>Java</b></p>
        
        </div>
    )
}

   



export default Headline;