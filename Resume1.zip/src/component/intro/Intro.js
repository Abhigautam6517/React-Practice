
import Buttons from '../btn/Button.js';
import Headline from './Headline.js';
import Images from '../img/image.js';
import './Intro.css';

function Introduction(){
    const field = "MERN STACK DEVELOPER";
    const name = `Abhishek Gautam`;
    return(
        <div className="intro">
        <h3 className="field">{field}</h3>
        <h2 className="my-name">Hello  My  Name  is</h2>
        <h4 className="name">{name}</h4>
        <Images></Images>
        <Headline></Headline>
       
        <Buttons btn = "Download" link = "" />
        <Buttons btn = "Hire me" link = "" />
        
        </div>
    )

}
export default Introduction;