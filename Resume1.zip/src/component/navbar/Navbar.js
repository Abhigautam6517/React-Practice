

import NavItem from './Nav-item.js';
import './Navbar.css';

    
function Navbar(){
    return(
        <nav>
            
            
             <h2 className = "online-resume">Online Resume</h2>
           
            <NavItem title = "Live-Project" link=""/>
            <NavItem title = "My-Github" link="https://github.com/Abhigautam6517"/>
            <NavItem title = "Project" link=""/>
            <NavItem title = "About Me" link=""/>
            <NavItem title = "Home" link=""/>
            
            
            
        </nav>
        
    );
}

export default Navbar;