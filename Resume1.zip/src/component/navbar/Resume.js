
function Resume(){
    <li>
        Online Resume
    </li>
}
export default Resume;