import './Navbar.css';
function NavItem(props){
    return(
   
    <div className = "topnav-right">
    <li>
    <a href={props.link}>{props.title}</a>
   </li>
   </div>
 
   
  
);
}
export default NavItem;

