import  './images.css';
import pic from './image-resume.png';
function images(){
    return(
        <div classname = "img-head">
        <img className="img-src" src={pic} />
        </div>
        
       
    )
}
export default images;