import React, { PureComponent } from "react";
import { getPizza } from "../utils/api_clients";
import load from "../assets/load.gif";
import { Menu } from "../widgets/menu";
import Container from "@mui/material/Container";

import {PizzaCard} from "../widgets/card.js";

export class Shop extends PureComponent {
  constructor() {
    super();
    this.loading = true;
    this.state = { pizzas: [], loading: this.loading };
  }
  componentDidMount() {
    this.loadPizza();
  }
  componentWillUnmount() {
    // Clean Up Code
  }

  loadPizza() {
    const response = getPizza();
    
    response
      .then((res) => {
        this.loading = false;

        console.log("data is ", res.data["Vegetarian"]);
        this.setState({
          pizzas: res.data["Vegetarian"],
          loading: this.loading,
        });
        
      })
      .catch((err) => {
        console.log("Error is ", err);
      })
      .finally(() => {
        console.log("Always run ....");
      });
  }

  showPizza() {
    return this.state.pizzas.map((pizza, index) => (
      <PizzaCard pizza={pizza} key={index} />
    ));
  }



  render() {
    console.log("Render Call ", this.state.loading);
    const loadingJSX = <img src={load} />;
    return (
      <Container maxWidth="sm">
        <Menu />
        {this.state.loading ? loadingJSX : this.showPizza()}
      </Container>
    );
  }
}
