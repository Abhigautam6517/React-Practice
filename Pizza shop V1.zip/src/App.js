import logo from './logo.svg';
import './App.css';
import {Shop} from "./containers/Shop.js"

function App() {
  return (
    <Shop/>
  );
}

export default App;
