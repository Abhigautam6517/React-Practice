import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { Link } from "react-router-dom";
export const Menu = () => {
  const getMenus = () => {
    return [
      { name: "Pizzas", link: "/pizza" },
      { name: "Desserts", link: "/desserts" },
      { name: "Drinks", link: "/drinks" },
    ]; 
  };
  return (
    <Box sx={{ display: "flex", alignItems: "center", textAlign: "center"}}>
      {getMenus().map((menu, index) => (
        <Typography sx={{ minWidth: 100 }}>
          <Link to={menu.link}>{menu.name}</Link>
        </Typography>
      ))}
     
    </Box>
  );
};
