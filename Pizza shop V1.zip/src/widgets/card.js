import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import { red } from "@mui/material/colors";

import Avatar from "@mui/material/Avatar";

export const PizzaCard = ({pizza})=>{
    return(
        <Card sx={{ maxWidth: 345 }}>
      <CardHeader
        avatar={
          <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
            P
          </Avatar>
        }
        title={pizza.name}
        subheader={pizza.menu_description}
      />
      <CardMedia
        component="img"
        height="194"
        image={pizza.assets.menu[0].url}
        alt="Paella dish"
      />
      <CardContent>
        <p>{pizza.price}</p>
      </CardContent>
    </Card>

    )
}