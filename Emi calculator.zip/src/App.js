
import './App.css';
import {Logic} from './operations/Logic.js';
function App() {
  return (
    <div>
    <Logic/>
    </div>
   
  );
}

export default App;
