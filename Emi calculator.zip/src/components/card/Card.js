export const Card = ()=>{
    <div className="main-Card">

    </div>
}