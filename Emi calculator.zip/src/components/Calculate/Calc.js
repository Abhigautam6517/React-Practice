import React,{Componenet} from "react";


export class Calc extends React.Component {
    constructor(props) {
      super(props);
      this.state = {value: ''};
     
     
    }

    render(){
    return (
        <div>
            <div>
                <h4>Loan EMI</h4>
                <p>{this.props.value1} </p> 
            </div>
            <div>
            <h4>Total Interset Payable</h4>
            <p>{this.props.value}  </p>
            </div>
            <div>
            <h4>Total Payment
                <br><h4>(Principle+interset)</h4></br>
            </h4>
            <p>{this.props.value} </p>
            </div>
        </div>
    )

}

}