import './Heading.css';

export const Headings = ()=>{
    return(
        <div className = "head">
            <h1>EMI CALCULATOR </h1>
        </div>
    )
}