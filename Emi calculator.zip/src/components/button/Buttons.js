import './btn.css';
export const Buttons = (props)=>{
    return(
        <div className = "btn">
            <button>{props.title}</button>
        </div>
    )
}