import './struct.css';
import React,{Component} from 'react';


export class Structure extends React.Component {
    constructor(props) {
      super(props);
      this.state = {value1:'',value2:'',value3:''};
      this.storeInput1 = this.storeInput1.bind(this);
    
     
    }
  
    storeInput1(event) {  
        
        //   this.setState({value1: event.target.value}); 
        //   console.log("the value is",event.target.value)
        this.setState({ [event.target.name]: event.target.value });
         }
         
  
  
    render(){
    return(
        <div className = "struct">
           <label>Home Loan Amount</label>
            <input className="struct-input1"  type = "text" value={this.state.value1}/>
            <input  className= "struct-input2" name='value1'  type="range" min = "0" max="1000000" onChange={this.storeInput1}/>
            <label>Interset Rate</label>
            <input className="struct-input1"  type = "text" value={this.state.value2}/>
            <input  className= "struct-input2" name='value2'  type="range" min = "0" max="25" onChange={this.storeInput1}/>
            
            <label>Loan Tenure</label>
            <input className="struct-input1"  type = "text" value={this.state.value3}/>
            <input  className= "struct-input2" name='value3'   type="range" min = "0" max="15" onChange={this.storeInput1}/>
            
            
        </div>
    
            
    )
}
    
}