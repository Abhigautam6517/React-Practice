import './Logic.css';
import { Buttons } from "../components/button/Buttons";
import { Structure } from "../components/Structure/Structure.js";
import { Headings } from '../components/Heading/Headings.js';

export const Logic = ( )=>{
    return(
        <div className = "logic">
        <Headings/>
        <Buttons title = "Home Loan"/>
        <Buttons title = "Personal Loan"/>
        <Buttons title = "Car Loan"/>
        <Structure  min="0" max="1000000"/>
        
    
        

        </div>
    )
}