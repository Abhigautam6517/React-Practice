import React from "react";
import './Timer.css';

export class Timer extends React.Component{
    constructor(){
        super()
        this.state ={
            CurrentTime:new Date().toLocaleTimeString(),
            
            
            

        };
    }
        updateDateTime=()=>{  
            this.setState({CurrentTime: new Date().toLocaleTimeString()});
           
        }
    
        
       
    
    
    render(){
        setInterval(this.updateDateTime,1000);       
        return(
            <div className="container">
                <h2 className="time">Digital Timer</h2>
                <h3 className = "digital-head">{this.state.CurrentTime} </h3>
            </div>
        )
    }
}


