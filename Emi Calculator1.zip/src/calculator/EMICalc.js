import { InputField } from "../components/InputField";
import {Title} from "../components/Title";
import {Output} from "../components/Output";
import React,{Component} from 'react';


export class EMICalc extends Component {

    constructor(){
        super();
        this.valuePrice = "5000000";
        this.valueInterest = "7.5";
        this.valueloan = "20";
        this.emi = 0;
        this.totalPayment = 0;
        this.interestPay = 0;
        this.percentLoanAmount = 0;
        this.totalPercentInterest = 0;
        this.state = {price: this.valuePrice, interest: this.valueInterest, loan: this.valueloan, emi: this.emi, percentLoanAmount: this.percentLoanAmount, totalPercentInterest: this.totalPercentInterest};
    }

    price(event){
        console.log(event.target.value);
        let tt = this.valuePrice;
        this.valuePrice = event.target.value;
        this.setState({...this.state,price: this.valuePrice});
        
    }

    interest(event){
        this.valueInterest = event.target.value;
        this.setState({...this.state, interest: this.valueInterest});
    }

    loan(event){
        this.valueloan = event.target.value;
        this.setState({...this.state, loan: this.valueloan});
    }

    // clear() {
    //     this.valuePrice = "";
    //     this.setState({...this.state, price:this.valuePrice});
    // }

    emiMonth(){
        let rate = (this.valueInterest/12)/100;
        let p = this.valuePrice*rate;
        // let k = 1 + rate;
        // console.log(k)
        let r1 = Math.pow((1+parseFloat(rate)),(this.valueloan*12));
        let r2 = r1-1;
        this.emi = Math.round(p*(r1/r2));
        this.totalPayment = this.emi*(this.valueloan*12);
        this.interestPay = this.totalPayment - this.valuePrice;
        this.percentLoanAmount = Math.ceil(((this.interestPay/this.totalPayment)*100).toFixed(2));
        this.totalPercentInterest = 100-this.percentLoanAmount;
        this.setState({...this.state, emi: this.emi, totalPayment: this.totalPayment, interestPay: this.interestPay,percentLoanAmount: this.percentLoanAmount, totalPercentInterest: this.totalPercentInterest});
    }
    
    render() {
        return (
            <div className="container">
                <Title/>
                <InputField changePrice={this.price.bind(this)} changeInterest={this.interest.bind(this)} 
                changeloan={this.loan.bind(this)} valuePrice={this.state.price} 
                valueInterest={this.state.interest} valueloan={this.state.loan} calcEMI={this.emiMonth.bind(this)}
                />
                <Output emi={this.state.emi} totalPayment={this.state.totalPayment} interestPay={this.state.interestPay} percentLoanAmount={this.state.percentLoanAmount} totalPercentInterest={this.state.totalPercentInterest}/>
            </div>
        )
    }
}

// export const EMICalc = () => {
//     const EMICalc = {
//         margin: '10rem',
//     padding: '5rem'
//     }
//     return (<div style={EMICalc}>
//         <InputField/>
//     </div>);
// }