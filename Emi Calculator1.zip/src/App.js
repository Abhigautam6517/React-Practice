import {EMICalc} from './calculator/EMICalc.js';
import './App.css';

function App() {
  return (
    <EMICalc/>
   
  );
}

export default App;
