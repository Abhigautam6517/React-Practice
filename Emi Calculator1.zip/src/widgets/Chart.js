import 'chart.js/auto';
import {Pie} from 'react-chartjs-2';

export const Chart = ({pla, tpi}) => {
  // console.log(pla,tpi);
    const state = {
        labels: ['Principal Loan Amount', 'Total Interest'],
        datasets: [
          {
            label: 'Rainfall',
            backgroundColor: [
              'rgb(237, 140, 43)',
              'rgb(161, 193, 62)',
            ],
            hoverBackgroundColor: [
            'rgb(230, 122, 14)',
            'rgb(149, 191, 19)',
            ],
            data: [tpi,pla]
          }
        ]
      }
      const ChartCSS ={
        position: 'absolute',
        right: '150px',
      }
    return (<div style={ChartCSS}>
        <Pie
          data={state}
        //   options={{
        //     title:{
        //       display:true,
        //       text:'Average Rainfall per month',
        //       fontSize:20
        //     },
        //     legend:{
        //       display:true,
        //       position:'right'
        //     }
        //   }}
        />
        </div>)
}