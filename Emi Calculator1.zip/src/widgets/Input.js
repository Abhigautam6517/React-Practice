import './Input.css';
export const Input = (props) => {

    return (
    <div style={{margin:'3rem 0'}}>
        <div className="inputCSS">
            <h4>{props.title}</h4>
            <input type="text" value={props.value} onKeyDown={(event)=>{
                if(event.key === 'Enter'){
                    props.calcemi();
                }
            }} onChange={(event)=>{
                // console.log(event.target.value);
                props.change(event);
            }}/>
            
            <span className="symbol">{props.symbol}</span>
        </div>
        <div>
            <input type="range" value={props.value} class="form-control-range" id="formControlRange" onMouseUp={props.calcemi} step={props.step} min={props.min} max={props.max} onChange={(event) => {
                props.change(event);
            }}/>

        </div>
        
    </div>)
}