
export const ShownFields = (props) => {
    const FieldCSS = {
        textAlign : 'center',
        marginBottom : '20px',
    }
    const currency = new Intl.NumberFormat().format(props.pay)

    return (<div style={FieldCSS}>
        <div>
            <h3>{props.title}</h3>
        </div>
        <div>
            <h2><span>₹</span>{currency}</h2>
        </div>
    </div>)
}