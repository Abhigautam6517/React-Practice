import { ShownFields } from "../widgets/ShownFields.js";
import {Chart } from "../widgets/Chart.js";

export const Output = (props) => {

    const OutputCSS = {
        display: "flex",
        position: "relative"
    }
    return (<div style={OutputCSS}>
            <div>
                <ShownFields title="Loan EMI" pay={props.emi}/>
                <ShownFields title="Total Interest Payable" pay={props.interestPay} />
                <ShownFields title="Total Payment (Principal + Interest)" pay={props.totalPayment}/>
            </div>
                <Chart pla={props.percentLoanAmount} tpi={props.totalPercentInterest}/>
            </div>)
}