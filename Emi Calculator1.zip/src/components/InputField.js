import {Input} from '../widgets/Input'
import React, {Component} from 'react';


export const InputField = (props) =>{

    return (<>
    <Input title="Home Loan Amount" symbol="₹" min="0" max="20000000" change={props.changePrice} value={props.valuePrice} step="1" calcemi={props.calcEMI}/>
    <Input title="Interest Rate" symbol="%" min="5" max="20" change={props.changeInterest} value={props.valueInterest} step="0.25" calcemi={props.calcEMI}/>
    <Input title="Loan Tensure" symbol="Yr" min="0" max="30" change={props.changeloan} value={props.valueloan} step="0.5" calcemi={props.calcEMI}/></>)
}