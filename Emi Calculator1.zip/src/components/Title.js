export const Title = () => {
    return (<h1 style={{textAlign: 'center'}}>EMI Calculator</h1>)
}